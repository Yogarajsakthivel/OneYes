import logo from "./logo.svg";
import "./App.css";
import DashboardPage from "./Dashboard/DashboardPage";
import { BrowserRouter } from "react-router-dom";

function App() {
  return (
    <div className="App">
      
        <DashboardPage />
    
    </div>
  );
}

export default App;
