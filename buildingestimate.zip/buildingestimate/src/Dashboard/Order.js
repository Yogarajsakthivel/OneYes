import React, { useState } from "react";
import { Link } from "react-router-dom";
import Sales from "./Sales";

const Orders = () => {

  const [formData, setFormData] = useState({
    kitchen: 0,
    bedroom: 0,
    washroom: 0,
    hall: 0,
    k_sqt: 0,
    b_sqt: 0,
    w_sqt: 0,
    h_sqt: 0,
  });

  console.log(formData)

  const [kitchen, setKitchen] = useState(0);
  const [bedroom, setBedroom] = useState(0);
  const [washroom, setWashroom] = useState(0);
  const [hall, setHall] = useState(0);
  const [totalExpense, setTotalExpense] = useState(0);



  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.id]: e.target.value,
    });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  
  };
  

  return (
    <>
      <div
        style={{
          backgroundImage: `url("https://c4.wallpaperflare.com/wallpaper/287/770/462/construction-danger-design-grunge-wallpaper-preview.jpg")`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          height: "100vh",
          display: "flex",
          justifyContent: "space-around",
          color: "white",
          fontFamily: "Arial, sans-serif",
        }}
      >
        <div style={{ width: "45%", padding: "20px", height: "80%" }}>
          <h1
            style={{
              fontSize: "36px",
              color: "red",
              marginTop: "180px",
              textAlign: "center",
            }}
          >
            Number of Rooms
          </h1>
          <form
            onSubmit={handleSubmit}
            style={{ fontSize: "18px", textAlign: "left" }}
          >
            <table style={{ margin: "0 auto" }}>
              <tbody>
                <tr>
                  <td>No of Kitchen:</td>
                  <td>
                    <input
                      type="number"
                      id="kitchen"
                      className="form-control"
                      onChange={handleChange}
                    />
                  </td>
                </tr>
                <tr>
                  <td>No of Bedroom:</td>
                  <td>
                    <input
                      type="number"
                      id="bedroom"
                      className="form-control"
                      onChange={handleChange}
                    />
                  </td>
                </tr>
                <tr>
                  <td>No of Washroom:</td>
                  <td>
                    <input
                      type="number"
                      id="washroom"
                      className="form-control"
                      onChange={handleChange}
                    />
                  </td>
                </tr>
                <tr>
                  <td>No of Hall:</td>
                  <td>
                    <input
                      type="number"
                      id="hall"
                      className="form-control"
                      onChange={handleChange}
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </form>
        </div>

        <div style={{ width: "45%", padding: "20px", height: "80%" }}>
          <h1
            style={{
              fontSize: "36px",
              color: "red",
              marginTop: "180px",
              textAlign: "center",
            }}
          >
            Square Feet
          </h1>
          <form
            onSubmit={handleSubmit}
            style={{ fontSize: "18px", textAlign: "right" }}
          >
            <table style={{ margin: "0 auto" }}>
              <tbody>
                <tr>
                  <td>Kitchen SquareFeet:</td>
                  <td>
                    <input
                      type="number"
                      id="k_sqt"
                      className="form-control"
                      onChange={handleChange}
                    />
                  </td>
                </tr>
                <tr>
                  <td>Bedroom SquareFeet:</td>
                  <td>
                    <input
                      type="number"
                      id="b_sqt"
                      className="form-control"
                      onChange={handleChange}
                    />
                  </td>
                </tr>
                <tr>
                  <td>Washroom SquareFeet:</td>
                  <td>
                    <input
                      type="number"
                      id="w_sqt"
                      className="form-control"
                      onChange={handleChange}
                    />
                  </td>
                </tr>
                <tr>
                  <td>Hall SquareFeet:</td>
                  <td>
                    <input
                      type="number"
                      id="h_sqt"
                      className="form-control"
                      onChange={handleChange}
                    />
                  </td>
                </tr>
              </tbody>
            </table>
          </form>
        </div>
        <button
          className="btn btn-success"
          style={{
            height: "3em",
            position: " absolute",
            marginTop: "32em",
            color: "white",
          }}
        >
          Calculate Estimate
        </button>
      </div>

      <Sales data={formData} />
    </>
  );
};

export default Orders;
