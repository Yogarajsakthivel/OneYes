import React, { useState } from "react";
import { Link } from "react-router-dom";

const Dashboard = () => {
  const [pic, setPic] = useState("");
  const [bgpic, setBgPic] = useState("");
  function showImage(e) {
    const file = e.target.files[0];

    if (file) {
      const reader = new FileReader();

      reader.onload = (event) => {
        debugger;
        setPic(event.target.result);
        localStorage.setItem(pic, event.target.result);
      };

      reader.readAsDataURL(file);
    }
  }

  return (
    <div
      style={{
        height: "100vh", 
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        color: "white", 
      }}
    >
      <div
        style={{
          backgroundImage: `url(${
            bgpic ||
            "https://c4.wallpaperflare.com/wallpaper/331/937/124/architecture-building-construction-design-wallpaper-preview.jpg"
          })`,
          backgroundSize: "cover",
          width: "100%",
          height: "100%",
          position: "absolute",
          top: 0,
          left: 0,
          zIndex: -1,
        }}
      ></div>

      <div style={{ textAlign: "left", marginBottom: "20px", zIndex: 1 }}>
        <h1 style={{ fontSize: "36px", color: "#FFD700" }}>
          Welcome to Ryan's Builders
        </h1>
        <p style={{ fontSize: "18px", color: "#ffffff" }}>
          Your trusted partner in construction services. We deliver excellence,
          <br />
          quality, and innovation in every project.
        </p>
      </div>

      <input
        id="image"
        type="file"
        style={{ padding: "10px", border: "2px solid" }}
        onChange={(e) => showImage(e)}
        accept="image/*"
      />

      {pic && (
        <div style={{ marginTop: "20px", zIndex: 1 }}>
          <h2 style={{ fontSize: "24px", color: "#ffffff" }}>
            Uploaded Image:
          </h2>
          <img
            src={pic}
            alt="Uploaded"
            style={{
              maxWidth: "100%",
              maxHeight: "300px",
              borderRadius: "8px",
            }}
          />
        </div>
      )}

      <Link to="/orders" style={{ fontSize: "20px", color: "#ffffff" }}>
        Submit
      </Link>
    </div>
  );
};

export default Dashboard;
