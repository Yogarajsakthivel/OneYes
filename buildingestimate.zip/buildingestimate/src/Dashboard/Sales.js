import React, { useEffect, useState } from "react";

const Sales = ({ data }) => {
  const [kitchen, setKitchen] = useState(0);
  const [bedroom, setBedroom] = useState(0);
  const [washroom, setWashroom] = useState(0);
  const [hall, setHall] = useState(0);
  const [totalExpense, setTotalExpense] = useState(0);
   console.log(data)
  localStorage.clear();

  useEffect=(()=>{
    setKitchen(data.kitchen)
  },[data])
    
  const [kitchenE1, setKitchenE1] = useState(0);
  const [bedroomE1, setBedroomE1] = useState(data.bedroom);
  const [washroomE1, setWashroomE1] = useState(data.washroom);
  const [kitchenSqtE1, setKitchenSqt] = useState(data.k_sqt);
  const [bedroomSqtE1, setBedroomSqt] = useState(data.b_sqt);
  const [washroomSqtE1, setWashroomSqt] = useState(data.w_sqt);
  const [HallroomSqtE1, setHallSqt] = useState(data.h_sqt);
   console.log(kitchen)
  function calculate() {
    let oneSqttiles = 1;
    let tilesRate = 130;
    let Sync = 1000;
    let Light = 50;
    let Cement = 5000;
    let Steel = 10000;
    let Pipe = 2500;
    let Wiring = 1000;
    let Switch = 600;

    console.log(data.k_sqt)

    let totalKitchenTiles = oneSqttile * data.k_sqt;

    let totalKitchenTilesRate = totalKitchenTiles * tilesRate;

    let totalKitchenExpense =
      totalKitchenTilesRate +
      Sync +
      Light +
      Cement +
      Steel +
      Pipe +
      Wiring +
      Switch;

    setKitchen(totalKitchenExpense);

    let totalBedroomTiles = oneSqttiles * bedroomSqtE1;

    let totalBedroomTilesRate = totalBedroomTiles * tilesRate;

    let totalBedroomExpense =
      totalBedroomTilesRate + Light + Cement + Steel + Wiring;

    setBedroom(totalBedroomExpense);

    let totalWashroomTiles = oneSqttiles * washroomSqtE1;

    let totalWashroomTilesRate = totalWashroomTiles * tilesRate;

    let totalWashroomExpense =
      totalWashroomTilesRate + Sync + Light + Cement + Steel + Wiring;

    setWashroom(totalWashroomExpense);

    let totalHallTiles = oneSqttiles * HallroomSqtE1;

    let totalHallTilesRate = totalHallTiles * tilesRate;

    let totalHallExpense =
      totalHallTilesRate + Sync + Light + Cement + Steel + Wiring;

    setHall(totalHallExpense);

    let totalExpense =
      totalKitchenExpense +
      totalBedroomExpense +
      totalWashroomExpense +
      totalHallExpense;
    setTotalExpense(totalExpense);
  }

  return (
    <div
      style={{
        backgroundImage: `url("https://images.pexels.com/photos/531844/pexels-photo-531844.jpeg?cs=srgb&dl=pexels-pixabay-531844.jpg&fm=jpg")`,
        backgroundSize: "cover",
        backgroundPosition: "center",
        height: "100vh",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        color: "black",
        fontFamily: "Arial, sans-serif",
      }}
    >
      <h1>Sales</h1>
      <div>
        <p>
          Kitchen: {kitchenE1} Kitchen SquareFeet:{kitchenSqtE1}
        </p>
        <p>
          Bedroom: {bedroomE1} Bedroom SquareFeet: {bedroomSqtE1}
        </p>
        <p>
          Washroom: {washroomE1} Washroom SquareFeet: {washroomSqtE1}
        </p>
        <p>
          Hall: {HallroomSqtE1} Hall SquareFeet: {HallroomSqtE1}
        </p>
      </div>

      <button onClick={() => calculate()} style={{ margin: "10px" }}>
        Calculate
      </button>
      <h1>Estimation Cost</h1>
      <div>
        <p>Kitchen_Expense: {kitchen}</p>
        <p>Bedroom_Expense: {bedroom}</p>
        <p>Washroom_Expense: {washroom}</p>
        <p>Hall_Expense: {hall}</p>
        <h2>Total_Expense: {totalExpense}</h2>
      </div>
    </div>
  );
};

export default Sales;
