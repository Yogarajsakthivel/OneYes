import React, { useState } from "react";

const Sales = () => {
  const [kitchen, setKitchen] = useState(0);
  const [bedroom, setBedroom] = useState(0);
  const [washroom, setWashroom] = useState(0);
  const [hall, setHall] = useState(0);
  const [totalExpense, setTotalExpense] = useState(0);

  const [kitchenLength, setKitchenLength] = useState(0);
  const [kitchenWidth, setKitchenWidth] = useState(0);


  function calculate() {
    let oneSqttiles = 1;
    let tilesRate = 130;
    let Sync = 1000;
    let Light = 50;
    let Cement = 5000;
    let Steel = 10000;
    let Pipe = 2500;
    let Wiring = 1000;
    let Switch = 600;

    let totalKitchenSqt = kitchenLength * kitchenWidth;
    let totalKitchenTiles = oneSqttiles * totalKitchenSqt;

    let totalKitchenTilesRate = totalKitchenTiles * tilesRate;

    let totalKitchenExpense =
      totalKitchenTilesRate + Sync + Light + Cement + Steel + Pipe + Wiring + Switch;

    setKitchen(totalKitchenExpense);

   

    let totalExpense =
      totalKitchenExpense +
     
      ;
    setTotalExpense(totalExpense);
  }

  return (
    <div
      style={{
        // your styling here
      }}
    >
      <h1>Sales</h1>
      <div>
        {/* Input for Kitchen */}
        <label>
          Kitchen Length:
          <input
            type="number"
            value={kitchenLength}
            onChange={(e) => setKitchenLength(e.target.value)}
          />
        </label>
        <label>
          Kitchen Width:
          <input
            type="number"
            value={kitchenWidth}
            onChange={(e) => setKitchenWidth(e.target.value)}
          />
        </label>
        {/* Repeat the same for other rooms */}
      </div>

      <button onClick={() => calculate()} style={{ margin: "10px" }}>
        Calculate
      </button>
      <h1>Estimation Cost</h1>
      <div>
        <p>Kitchen_Expense: {kitchen}</p>
        {/* Repeat the same for other rooms */}
        <h2>Total_Expense: {totalExpense}</h2>
      </div>
    </div>
  );
};

export default Sales;
z