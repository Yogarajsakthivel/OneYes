import React from "react";
import {
  BrowserRouter,Routes,
  Route,
  Link,
} from "react-router-dom";
import Dashboard from "./Dashboard";
import Sales from "./Sales";
import Orders from "./Order";

const DashboardPage = () => {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Dashboard />} />
          <Route path="/sales" element={<Sales/>} />
          <Route path="/orders" element={<Orders />} />
        </Routes>
      </BrowserRouter>
    </>
  );
};

export default DashboardPage;
