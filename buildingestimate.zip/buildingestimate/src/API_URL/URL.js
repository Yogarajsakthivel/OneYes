export const API_URL = "https://65a0db09600f49256fb066d8.mockapi.io/building/"
